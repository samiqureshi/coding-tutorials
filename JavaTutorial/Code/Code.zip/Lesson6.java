public class Lesson6 {
    public static void main(String[] args){
        Planet p1 = new Planet("Pluto", 123456, 789456);
        System.out.println("Planet Name: " + p1.name);
        System.out.println("Planet Radius: " + p1.radius);
        System.out.println("Planet Distance: " + p1.distance);

    }
    
}
