public class Main {
    public static void main(String[] args){
        Planet p1 = new Planet("Jupiter", 354679413, 43562795);
        Planet p2 = new Planet("Saturn", 35628, 36278);

        p1.printInfo();
        p2.printInfo();
    }
}
